package programa;

public interface Recaudacion {
	
	public void recaudacion();

}
