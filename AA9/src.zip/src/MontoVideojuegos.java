
public interface MontoVideojuegos {
	
	public int montoVideojuegos(int cantidad, int precio_unitario);

}
