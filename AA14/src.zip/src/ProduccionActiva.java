
public interface ProduccionActiva {
	
	public int produccionActiva(int temperatura);

}
