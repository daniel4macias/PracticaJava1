
public class Golosina {

	int calorias;

}
