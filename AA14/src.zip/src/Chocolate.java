
public class Chocolate extends Golosina{
	
	String nombre;
	int cantidad;

}
