import java.util.List;

public interface GeneraArchivo {
	
	public void generaArchivo(List<String> informacion);

}
